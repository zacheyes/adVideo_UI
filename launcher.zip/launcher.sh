#!/bin/bash
# This script launches the Python UI and then closes the terminal window.

# --- Get the directory where the script is located for portability ---
# This ensures that the script can find the Python file, even if
# the script is run from a different working directory.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_SCRIPT="$SCRIPT_DIR/adVideo_UI.py"

# --- Set Terminal Title (Optional) ---
echo -ne "\033]0;Ad Video Tool Launcher\007"

# --- 1. Check for Python 3 installation ---
echo "Checking for Python 3 installation..."
if ! command -v python3 &> /dev/null
then
    # If Python 3 is not found, show an error and wait for user input.
    echo "ERROR: Python 3 is not installed or not found in your system's PATH."
    echo "Please install Python 3 from https://www.python.org/"
    read -r -p "Press Enter to exit..."
    exit 1
fi

# --- 2. Install required packages ---
echo "Installing required packages (if missing)..."
python3 -m pip install --quiet --disable-pip-version-check requests pandas

# --- 3. Launch the UI and Exit ---
echo "Launching the Ad Video Tool..."

# Launch the python script in the background using a subshell to detach it.
(nohup python3 "$PYTHON_SCRIPT" &>/dev/null &)

# Launch a separate, detached process that will wait a moment
# and then close the terminal window. This avoids the "terminate" prompt
# because the main script will have already exited by the time this runs.
(sleep 1 && osascript -e 'tell application "Terminal" to close (get window 1)') &> /dev/null &

# The script exits immediately, leaving the detached closer process to run.
exit 0
